/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class LivesAmmo extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Heart", "./LivesAmmo/costumes/Heart.svg", {
        x: 31.641702732540608,
        y: 31.28797673086808,
      }),
      new Costume("Heart 2", "./LivesAmmo/costumes/Heart 2.svg", {
        x: 31.641702732540608,
        y: 31.28797673086808,
      }),
      new Costume("Ammo Case", "./LivesAmmo/costumes/Ammo Case.svg", {
        x: 20.66664499999999,
        y: 21.792712499999965,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "Death" }, this.whenIReceiveDeath),
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.TIMER_GREATER_THAN,
        { VALUE: () => this.stage.vars.thumbTimer },
        this.whengreaterthan
      ),
    ];

    this.vars.clone = 3;
    this.vars.cloneid = 1;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.lives = -1;
    this.visible = false;
    this.deleteThisClone();
  }

  *whenIReceivePlay() {
    this.stage.vars.lives = this.itemOf(this.stage.vars.upgrades, 0);
    this.visible = true;
    this.size = 100;
    this.costume = "Ammo Case";
    this.goto(135, 110);
    this.stage.vars.lives = this.itemOf(this.stage.vars.upgrades, 0);
    yield* this.instant(this.itemOf(this.stage.vars.upgrades, 0));
    while (!(this.toNumber(this.stage.vars.lives) === 0)) {
      yield* this.wait(this.random(4, 9));
      this.vars.cloneid = this.random(2, 4);
      this.createClone();
      yield;
    }
    this.deleteThisClone();
  }

  *instant(time) {
    this.vars.clone = 0;
    for (let i = 0; i < this.toNumber(time); i++) {
      this.vars.cloneid = 1;
      this.createClone();
      this.vars.clone++;
    }
  }

  *startAsClone() {
    if (this.toNumber(this.vars.cloneid) === 1) {
      this.size = 50;
      this.costume = "Heart";
      this.visible = true;
      this.goto(this.toNumber(this.vars.clone) * -35 + 220, 159);
      while (true) {
        if (
          this.compare(this.stage.vars.lives, this.vars.clone) === 0 ||
          this.compare(this.vars.clone, this.stage.vars.lives) > 0
        ) {
          this.costume = "Heart 2";
        } else {
          this.costume = "Heart";
        }
        yield;
      }
    }
    if (this.toNumber(this.vars.cloneid) === 2) {
      if (
        this.compare(
          this.stage.vars.lives,
          this.itemOf(this.stage.vars.upgrades, 0)
        ) < 0
      ) {
        this.size = 75;
        this.moveBehind();
        this.costume = "Heart";
        this.goto(230, this.random(-180, 180));
        while (!(this.compare(this.x, -230) < 0)) {
          this.x -= 9;
          if (this.touching(this.sprites["Player"].andClones())) {
            this.stage.vars.lives++;
            this.deleteThisClone();
          }
          yield;
        }
      }
      this.deleteThisClone();
    }
    if (this.compare(this.vars.cloneid, 2) > 0) {
      if (
        this.compare(
          this.stage.vars.ammo,
          this.itemOf(this.stage.vars.upgrades, 2)
        ) < 0
      ) {
        this.size = 90;
        this.moveBehind();
        this.costume = "Ammo Case";
        this.goto(230, this.random(-180, 180));
        while (!(this.compare(this.x, -230) < 0)) {
          this.x -= 9;
          if (this.touching(this.sprites["Player"].andClones())) {
            this.stage.vars.ammo++;
            this.deleteThisClone();
          }
          yield;
        }
      }
      this.deleteThisClone();
    }
  }

  *whenIReceiveDeath() {
    this.visible = false;
    this.deleteThisClone();
  }

  *whenIReceiveMenu() {
    this.stage.vars.lives = -1;
    this.visible = false;
  }

  *whengreaterthan() {
    this.visible = false;
  }
}
