/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Numbers extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Numbers/costumes/1.svg", {
        x: 1.25,
        y: 19.48124999999999,
      }),
      new Costume("2", "./Numbers/costumes/2.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("3", "./Numbers/costumes/3.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("4", "./Numbers/costumes/4.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("5", "./Numbers/costumes/5.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("6", "./Numbers/costumes/6.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("7", "./Numbers/costumes/7.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("8", "./Numbers/costumes/8.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("9", "./Numbers/costumes/9.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume("0", "./Numbers/costumes/0.svg", {
        x: 4,
        y: 19.48124999999999,
      }),
      new Costume(".", "./Numbers/costumes/..svg", {
        x: 2,
        y: 19.48124999999999,
      }),
      new Costume("", "./Numbers/costumes/.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [new Sound("pop", "./Numbers/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.BROADCAST, { name: "Shop" }, this.whenIReceiveShop),
      new Trigger(Trigger.BROADCAST, { name: "Death" }, this.whenIReceiveDeath),
    ];

    this.vars.cloneNumbers = 0;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.score = 0;
    this.visible = false;
  }

  *whenIReceivePlay() {
    this.stage.vars.score = 0;
    this.vars.cloneNumbers = 0;
    yield* this.instantLoad(18);
    while (!(this.toNumber(this.stage.vars.lives) === 0)) {
      this.stage.vars.score++;
      yield* this.wait(1);
      yield;
    }
    return;
  }

  *instantLoad(repeatTimes) {
    for (let i = 0; i < Math.abs(this.toNumber(repeatTimes)); i++) {
      if (this.compare(repeatTimes, -1) > 0) {
        this.vars.cloneNumbers++;
      } else {
        this.vars.cloneNumbers--;
      }
      this.createClone();
    }
  }

  *startAsClone() {
    this.visible = true;
    while (true) {
      yield* this.cloneSizeBrightPosWhere(
        -36,
        -30,
        130,
        -100,
        19,
        670,
        155,
        -36,
        "money",
        0
      );
      yield* this.cloneSizeBrightPosWhere(
        -31,
        -25,
        100,
        -100,
        15,
        650,
        -150,
        -31,
        "item",
        3
      );
      yield* this.cloneSizeBrightPosWhere(
        -26,
        -20,
        100,
        -100,
        13,
        328,
        -150,
        -26,
        "item",
        2
      );
      yield* this.cloneSizeBrightPosWhere(
        -21,
        -15,
        100,
        -100,
        15,
        190,
        -150,
        -21,
        "item",
        1
      );
      yield* this.cloneSizeBrightPosWhere(
        -16,
        -10,
        100,
        -100,
        15,
        376,
        -126,
        -16,
        "cost",
        3
      );
      yield* this.cloneSizeBrightPosWhere(
        -11,
        -5,
        100,
        -100,
        15,
        152,
        -126,
        -11,
        "cost",
        2
      );
      yield* this.cloneSizeBrightPosWhere(
        -6,
        1,
        100,
        -100,
        15,
        -70,
        -126,
        -6,
        "cost",
        1
      );
      yield* this.cloneSizeBrightPosWhere(
        0,
        8,
        130,
        -100,
        19,
        -145,
        156,
        0,
        "score",
        0
      );
      yield* this.cloneSizeBrightPosWhere(
        7,
        10,
        130,
        -100,
        19,
        20,
        105,
        7,
        "ammo",
        0
      );
      yield* this.cloneSizeBrightPosWhere(
        12,
        18,
        130,
        -100,
        19,
        -365,
        119,
        12,
        "money",
        0
      );
      yield;
    }
  }

  *whenIReceiveMenu() {
    this.vars.cloneNumbers = 0;
    this.deleteThisClone();
  }

  *whenIReceiveShop() {
    this.vars.cloneNumbers = 0;
    yield* this.instantLoad(-35);
  }

  *cloneSizeBrightPosWhere(
    _,
    _2,
    size,
    brightness,
    distance,
    x,
    y,
    _3,
    ammoPointsCost,
    itemIfList
  ) {
    if (
      this.compare(this.vars.cloneNumbers, _) > 0 &&
      this.compare(this.vars.cloneNumbers, _2) < 0
    ) {
      this.size = this.toNumber(size);
      this.goto(
        this.toNumber(this.vars.cloneNumbers) * this.toNumber(distance) +
          this.toNumber(x),
        this.toNumber(y)
      );
      this.effects.brightness = this.toNumber(brightness);
      if (this.toString(ammoPointsCost) === "score") {
        this.costume = this.letterOf(
          this.stage.vars.score,
          this.toNumber(this.vars.cloneNumbers) - this.toNumber(_3) - 1
        );
      }
      if (this.toString(ammoPointsCost) === "ammo") {
        this.costume = this.letterOf(
          this.stage.vars.ammo,
          this.toNumber(this.vars.cloneNumbers) - this.toNumber(_3) - 1
        );
      }
      if (this.toString(ammoPointsCost) === "money") {
        this.costume = this.letterOf(
          this.stage.vars.money,
          this.toNumber(this.vars.cloneNumbers) - this.toNumber(_3) - 1
        );
      }
      if (this.toString(ammoPointsCost) === "cost") {
        this.costume = this.letterOf(
          this.itemOf(this.stage.vars.upgradeCost, itemIfList - 1),
          this.toNumber(this.vars.cloneNumbers) - this.toNumber(_3) - 1
        );
      }
      if (this.toString(ammoPointsCost) === "item") {
        this.costume = this.letterOf(
          this.itemOf(this.stage.vars.upgrades, itemIfList - 1),
          this.toNumber(this.vars.cloneNumbers) - this.toNumber(_3) - 1
        );
      }
    }
  }

  *whenIReceiveDeath() {
    this.deleteThisClone();
  }
}
