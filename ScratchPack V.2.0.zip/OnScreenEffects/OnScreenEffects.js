/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class OnScreenEffects extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Play", "./OnScreenEffects/costumes/Play.svg", {
        x: 232.88475836986305,
        y: 187.40404791742287,
      }),
      new Costume("Shop", "./OnScreenEffects/costumes/Shop.svg", {
        x: 108.04685750000002,
        y: 185.40404791742287,
      }),
      new Costume("Settings", "./OnScreenEffects/costumes/Settings.svg", {
        x: 225.27249217785845,
        y: 39.758402271777186,
      }),
      new Costume("Beam", "./OnScreenEffects/costumes/Beam.svg", {
        x: 19.99999999999997,
        y: 181.5,
      }),
      new Costume(
        "Death Screen",
        "./OnScreenEffects/costumes/Death Screen.svg",
        { x: 245.1919415342477, y: 185.3534319931515 }
      ),
    ];

    this.sounds = [new Sound("pop", "./OnScreenEffects/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay),
      new Trigger(
        Trigger.TIMER_GREATER_THAN,
        { VALUE: () => this.stage.vars.thumbTimer },
        this.whengreaterthan
      ),
      new Trigger(Trigger.BROADCAST, { name: "Death" }, this.whenIReceiveDeath),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "Shop" }, this.whenIReceiveShop),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Settings" },
        this.whenIReceiveSettings
      ),
    ];
  }

  *whenIReceiveMenu() {
    this.costume = "Shop";
    this.visible = false;
    this.deleteThisClone();
  }

  *whenIReceivePlay() {
    this.costume = "Play";
    this.visible = true;
    while (!(this.toNumber(this.stage.vars.lives) === 0)) {
      this.createClone();
      yield* this.wait(3);
      yield;
    }
  }

  *whengreaterthan() {
    this.visible = false;
  }

  *whenIReceiveDeath() {
    this.visible = false;
    yield* this.wait(3);
    this.costume = "Death Screen";
    this.visible = true;
    this.deleteThisClone();
  }

  *startAsClone() {
    this.costume = "Beam";
    this.goto(260, 0);
    while (!(this.compare(this.x, -240) < 0)) {
      this.moveBehind();
      this.x -= 10;
      yield;
    }
    this.deleteThisClone();
  }

  *whenIReceiveShop() {
    this.visible = true;
  }

  *whenIReceiveSettings() {
    this.costume = "Settings";
    this.visible = true;
    this.deleteThisClone();
  }
}
