/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("flying", "./Player/costumes/flying.svg", {
        x: 55.50063,
        y: 49.49923123621889,
      }),
      new Costume("flying 2", "./Player/costumes/flying 2.svg", {
        x: 59.056175000000025,
        y: 49.4992305298081,
      }),
      new Costume("idle flying", "./Player/costumes/idle flying.svg", {
        x: 46.75022990479593,
        y: 49.49923017660271,
      }),
      new Costume("Walking 1", "./Player/costumes/Walking 1.svg", {
        x: 47.58949641409055,
        y: 49.82001273645395,
      }),
      new Costume("Walking 2", "./Player/costumes/Walking 2.svg", {
        x: 45.95391015077087,
        y: 52.40377517660272,
      }),
      new Costume("ded 1", "./Player/costumes/ded 1.svg", {
        x: 47.67898262622364,
        y: 49.499230883013496,
      }),
      new Costume("ded 2", "./Player/costumes/ded 2.svg", {
        x: 47.67897762622357,
        y: 49.499230883013496,
      }),
      new Costume("flying2", "./Player/costumes/flying2.png", { x: 22, y: 22 }),
    ];

    this.sounds = [
      new Sound("recording1", "./Player/sounds/recording1.wav"),
      new Sound("Oops", "./Player/sounds/Oops.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay),
      new Trigger(
        Trigger.TIMER_GREATER_THAN,
        { VALUE: () => this.stage.vars.thumbTimer },
        this.whengreaterthan
      ),
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Player Hurt" },
        this.whenIReceivePlayerHurt
      ),
      new Trigger(Trigger.BROADCAST, { name: "Death" }, this.whenIReceiveDeath),
    ];

    this.vars.frame = 62;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.playerVelocity = 0;
    this.stage.vars.upgrades = [];
    this.stage.vars.upgradeShow = [];
    this.stage.vars.upgradeCost = [];
    this.stage.vars.upgrades.push(3);
    this.stage.vars.upgradeShow.push("Health");
    this.stage.vars.upgradeCost.push(100);
    this.stage.vars.upgrades.push(1);
    this.stage.vars.upgradeShow.push("Bullet Firing Speed (seconds)");
    this.stage.vars.upgradeCost.push(100);
    this.stage.vars.upgrades.push(10);
    this.stage.vars.upgradeShow.push("Amount of Ammo");
    this.stage.vars.upgradeCost.push(100);
    this.visible = false;
  }

  *whenIReceivePlay() {
    this.effects.clear();
    this.direction = 90;
    this.costume = "Walking 1";
    this.goto(-150, -140);
    this.visible = true;
    while (true) {
      if (this.compare(this.stage.vars.lives, 0) > 0) {
        this.y += this.toNumber(this.stage.vars.playerVelocity);
        if (this.compare(this.y, 140) > 0) {
          this.y = 140;
          this.stage.vars.playerVelocity = 0;
        } else {
          if (this.compare(this.y, -140) < 0) {
            this.y = -140;
            this.stage.vars.playerVelocity = 0;
            this.costume = "ded 2";
          }
        }
        if (this.keyPressed("w") || this.keyPressed("up arrow")) {
          this.costume = (this.toNumber(this.vars.frame) % 2) + 1;
          this.vars.frame++;
          if (this.compare(this.stage.vars.playerVelocity, 10) < 0) {
            this.stage.vars.playerVelocity += 0.5;
          }
        } else {
          this.stage.vars.playerVelocity -= 0.5;
          if (this.compare(this.stage.vars.playerVelocity, -10) < 0) {
            this.stage.vars.playerVelocity = -10;
          }
          if (this.y === -140) {
            this.costume = (this.toNumber(this.vars.frame) % 2) + 4;
            yield* this.wait(0.1);
            this.vars.frame++;
          } else {
            this.costume = "idle flying";
            this.vars.frame = 0;
          }
        }
      } else {
        this.costume = "ded 2";
        this.broadcast("Death");
        return;
      }
      yield;
    }
  }

  *whengreaterthan() {
    this.visible = false;
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenIReceivePlayerHurt() {
    if (this.compare(this.stage.vars.lives, 0) > 0) {
      if (this.toNumber(this.stage.vars.soundeffects) === 1) {
        yield* this.startSound("Oops");
      }
      for (let i = 0; i < 10; i++) {
        yield* this.wait(0.15);
        this.effects.brightness += 20;
        yield* this.wait(0.15);
        this.effects.brightness -= 20;
        yield;
      }
      this.effects.brightness = 0;
    }
  }

  *whenIReceiveDeath() {
    for (let i = 0; i < 6; i++) {
      this.direction -= 15;
      this.x -= 5;
      this.y -= 5;
      yield;
    }
    while (!(this.compare(this.y, -180) < 0)) {
      this.y -= 10;
      yield;
    }
  }
}
