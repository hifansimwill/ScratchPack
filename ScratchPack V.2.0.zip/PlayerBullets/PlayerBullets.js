/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class PlayerBullets extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Bullet 1", "./PlayerBullets/costumes/Bullet 1.svg", {
        x: 6.833336666666668,
        y: 6.833336666666668,
      }),
    ];

    this.sounds = [
      new Sound(
        "recording2 from 2022",
        "./PlayerBullets/sounds/recording2 from 2022.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay),
      new Trigger(Trigger.BROADCAST, { name: "Death" }, this.whenIReceiveDeath),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay2),
    ];
  }

  *startAsClone() {
    this.costume = "Bullet 1";
    this.moveBehind();
    this.visible = true;
    this.goto(this.sprites["Player"].x + 10, this.sprites["Player"].y - 10);
    while (
      !(
        this.touching(this.sprites["Enemies"].andClones()) ||
        this.compare(this.x, 200) > 0
      )
    ) {
      this.x += 10;
      yield;
    }
    this.deleteThisClone();
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceivePlay() {
    this.stage.vars.ammo = this.itemOf(this.stage.vars.upgrades, 2);
    while (true) {
      if (this.keyPressed("space")) {
        if (this.compare(this.sprites["Player"].costumeNumber, 4) < 0) {
          if (this.compare(this.stage.vars.ammo, 0) > 0) {
            if (this.toNumber(this.stage.vars.soundeffects) === 1) {
              yield* this.startSound("recording2 from 2022");
            }
            this.createClone();
            this.stage.vars.ammo--;
            yield* this.wait(
              this.toNumber(this.itemOf(this.stage.vars.upgrades, 1))
            );
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveDeath() {
    this.visible = false;
    this.deleteThisClone();
  }

  *whenIReceivePlay2() {
    while (true) {
      if (
        this.compare(
          this.stage.vars.ammo,
          this.toNumber(this.itemOf(this.stage.vars.upgrades, 2)) + 1
        ) < 0
      ) {
        this.stage.vars.ammo = this.stage.vars.ammo;
      } else {
        this.stage.vars.ammo = this.itemOf(this.stage.vars.upgrades, 2);
      }
      yield;
    }
  }
}
