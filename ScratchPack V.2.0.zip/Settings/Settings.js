/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Settings extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Easy", "./Settings/costumes/Easy.svg", {
        x: 25.25,
        y: 19.48124999999999,
      }),
      new Costume("Medium", "./Settings/costumes/Medium.svg", {
        x: 36.5,
        y: 19.25,
      }),
      new Costume("Hard", "./Settings/costumes/Hard.svg", {
        x: 26.5,
        y: 19.25,
      }),
      new Costume("Off", "./Settings/costumes/Off.svg", { x: 20.25, y: 19.25 }),
      new Costume("On", "./Settings/costumes/On.svg", { x: 14, y: 19.25 }),
      new Costume("Arrow", "./Settings/costumes/Arrow.svg", {
        x: 7.1447,
        y: 14.2894,
      }),
    ];

    this.sounds = [new Sound("pop", "./Settings/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];

    this.vars.clone = 0;
  }

  *whenIReceiveMenu() {
    this.visible = false;
    this.deleteThisClone();
  }

  *whenGreenFlagClicked() {
    this.stage.vars.difficulty = 1;
    this.stage.vars.music = 1;
    this.stage.vars.soundeffects = 1;
    this.visible = false;
  }

  *whenIReceiveSettings() {
    yield* this.createClones();
  }

  *createClones() {
    this.vars.clone = 0;
    for (let i = 0; i < 9; i++) {
      this.vars.clone++;
      this.createClone();
    }
    this.vars.clone = 0;
  }

  *startAsClone() {
    this.visible = true;
    if (this.toNumber(this.vars.clone) === 1) {
      this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
      this.costume = "Arrow";
      this.goto(30, 15);
      this.direction = -90;
      while (true) {
        this.effects.ghost =
          (1 - this.toNumber(this.stage.vars.soundeffects)) * 80;
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 2) {
      this.goto(65, 15);
      while (true) {
        this.costume = 4 + this.toNumber(this.stage.vars.soundeffects);
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 3) {
      this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
      this.costume = "Arrow";
      this.goto(100, 15);
      this.direction = 90;
      while (true) {
        this.effects.ghost = this.toNumber(this.stage.vars.soundeffects) * 80;
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 4) {
      this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
      this.costume = "Arrow";
      this.goto(-115, -35);
      this.direction = -90;
      while (true) {
        this.effects.ghost = (1 - this.toNumber(this.stage.vars.music)) * 80;
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 5) {
      this.goto(-80, -35);
      while (true) {
        this.costume = 4 + this.toNumber(this.stage.vars.music);
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 6) {
      this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
      this.costume = "Arrow";
      this.goto(-45, -35);
      this.direction = 90;
      while (true) {
        this.effects.ghost = this.toNumber(this.stage.vars.music) * 80;
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 7) {
      this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
      this.costume = "Arrow";
      this.goto(-50, -80);
      this.direction = -90;
      while (true) {
        this.effects.ghost = 0;
        if (this.toNumber(this.stage.vars.difficulty) === 0) {
          this.effects.ghost = 80;
        }
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 8) {
      this.goto(0, -83);
      while (true) {
        this.costume = 1 + this.toNumber(this.stage.vars.difficulty);
        yield;
      }
    }
    if (this.toNumber(this.vars.clone) === 9) {
      this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
      this.costume = "Arrow";
      this.goto(50, -80);
      this.direction = 90;
      while (true) {
        this.effects.ghost =
          (this.toNumber(this.stage.vars.difficulty) - 1) * 80;
        yield;
      }
    }
  }

  *whenthisspriteclicked() {
    yield* this.click();
  }

  *click() {
    if (this.toNumber(this.vars.clone) === 1) {
      this.stage.vars.soundeffects--;
      if (this.compare(this.stage.vars.soundeffects, 0) < 0) {
        this.stage.vars.soundeffects = 0;
      }
    }
    if (this.toNumber(this.vars.clone) === 3) {
      this.stage.vars.soundeffects++;
      if (this.compare(this.stage.vars.soundeffects, 1) > 0) {
        this.stage.vars.soundeffects = 1;
      }
    }
    if (this.toNumber(this.vars.clone) === 4) {
      this.stage.vars.music--;
      if (this.compare(this.stage.vars.music, 0) < 0) {
        this.stage.vars.music = 0;
      }
    }
    if (this.toNumber(this.vars.clone) === 6) {
      this.stage.vars.music++;
      if (this.compare(this.stage.vars.music, 1) > 0) {
        this.stage.vars.music = 1;
      }
    }
    if (this.toNumber(this.vars.clone) === 7) {
      this.stage.vars.difficulty--;
      if (this.compare(this.stage.vars.difficulty, 0) < 0) {
        this.stage.vars.difficulty = 0;
      }
    }
    if (this.toNumber(this.vars.clone) === 9) {
      this.stage.vars.difficulty++;
      if (this.compare(this.stage.vars.difficulty, 2) > 0) {
        this.stage.vars.difficulty = 2;
      }
    }
  }
}
