/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Shop extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Health Upgrade", "./Shop/costumes/Health Upgrade.svg", {
        x: 67.5,
        y: 67.5,
      }),
      new Costume(
        "Firing Rate Upgrade",
        "./Shop/costumes/Firing Rate Upgrade.svg",
        { x: 67.5, y: 67.5 }
      ),
      new Costume(
        "Ammo Capacity Upgrade",
        "./Shop/costumes/Ammo Capacity Upgrade.svg",
        { x: 67.5, y: 68.38479833333334 }
      ),
      new Costume("Screen", "./Shop/costumes/Screen.svg", {
        x: 239.24102492831813,
        y: 42.245175675674716,
      }),
    ];

    this.sounds = [new Sound("pop", "./Shop/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.BROADCAST, { name: "Shop" }, this.whenIReceiveShop),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.TIMER_GREATER_THAN,
        { VALUE: () => this.stage.vars.thumbTimer },
        this.whengreaterthan
      ),
    ];

    this.vars.clone = 3;
  }

  *whenIReceiveMenu() {
    this.visible = false;
    this.deleteThisClone();
  }

  *whenIReceiveShop() {
    this.goto(0, 0);
    this.visible = true;
    yield* this.instant(3);
    this.costume = "Screen";
    this.moveBehind();
  }

  *instant(_) {
    this.vars.clone = 0;
    for (let i = 0; i < this.toNumber(_); i++) {
      this.vars.clone++;
      this.createClone();
    }
  }

  *startAsClone() {
    this.visible = true;
    while (true) {
      if (this.toNumber(this.vars.clone) === 1) {
        this.costume = "Health Upgrade";
        this.goto(this.toNumber(this.vars.clone) * 150 - 300, -40);
      }
      if (this.toNumber(this.vars.clone) === 2) {
        this.costume = "Firing Rate Upgrade";
        this.goto(this.toNumber(this.vars.clone) * 150 - 300, -40);
      }
      if (this.toNumber(this.vars.clone) === 3) {
        this.costume = "Ammo Capacity Upgrade";
        this.goto(this.toNumber(this.vars.clone) * 150 - 300, -40);
      }
      if (this.touching("mouse")) {
        this.size += (105 - this.size) / 2;
      } else {
        this.size += (100 - this.size) / 2;
      }
      this.effects.brightness = ((105 - this.size) / 2) * -1;
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.compare(this.vars.clone, 0) > 0) {
      if (
        this.compare(
          this.stage.vars.money,
          this.toNumber(
            this.itemOf(this.stage.vars.upgradeCost, this.vars.clone - 1)
          ) - 1
        ) > 0
      ) {
        if (this.toNumber(this.vars.clone) === 1) {
          if (this.compare(this.itemOf(this.stage.vars.upgrades, 0), 7) < 0) {
            this.stage.vars.upgrades.splice(
              0,
              1,
              this.toNumber(this.itemOf(this.stage.vars.upgrades, 0)) + 1
            );
            yield* this.moneychange();
          }
        }
        if (this.toNumber(this.vars.clone) === 2) {
          if (
            this.compare(this.itemOf(this.stage.vars.upgrades, 1), 0.11) > 0
          ) {
            this.stage.vars.upgrades.splice(
              1,
              1,
              this.toNumber(this.itemOf(this.stage.vars.upgrades, 1)) + -0.1
            );
            yield* this.moneychange();
          } else {
            null;
          }
        }
        if (this.toNumber(this.vars.clone) === 3) {
          if (this.compare(this.itemOf(this.stage.vars.upgrades, 2), 50) < 0) {
            this.stage.vars.upgrades.splice(
              2,
              1,
              this.toNumber(this.itemOf(this.stage.vars.upgrades, 2)) + 5
            );
            yield* this.moneychange();
          }
        }
      } else {
        this.broadcast("Insufficient Funds");
      }
    }
  }

  *whengreaterthan() {
    this.visible = false;
  }

  *moneychange() {
    this.stage.vars.money +=
      this.toNumber(
        this.itemOf(this.stage.vars.upgradeCost, this.vars.clone - 1)
      ) * -1;
    this.stage.vars.upgradeCost.splice(
      this.vars.clone - 1,
      1,
      Math.round(
        this.toNumber(
          this.itemOf(this.stage.vars.upgradeCost, this.vars.clone - 1)
        ) * 2.5
      )
    );
  }
}
