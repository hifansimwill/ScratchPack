/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class SpecialEffects extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "HitParticles",
        "./SpecialEffects/costumes/HitParticles.svg",
        { x: 11.499999999999972, y: 11.500007916666675 }
      ),
    ];

    this.sounds = [new Sound("pop", "./SpecialEffects/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Player Hurt" },
        this.whenIReceivePlayerHurt
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
    ];
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenIReceivePlayerHurt() {
    yield* this.instantclones(this.random(4, 7));
  }

  *startAsClone() {
    this.visible = true;
    this.effects.clear();
    this.moveAhead();
    this.goto(this.sprites["Player"].x, this.sprites["Player"].y);
    this.direction = this.random(0, 359);
    for (let i = 0; i < this.random(5, 10); i++) {
      this.move(this.random(2, 5));
      yield;
    }
  }

  *instantclones(times) {
    for (let i = 0; i < this.toNumber(times); i++) {
      this.createClone();
    }
  }

  *startAsClone2() {
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      yield;
    }
    this.deleteThisClone();
  }
}
