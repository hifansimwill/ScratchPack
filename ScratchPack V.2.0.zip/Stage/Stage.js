/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("screen1", "./Stage/costumes/screen1.svg", {
        x: 274.23722648620605,
        y: 183.00000000000006,
      }),
      new Costume("screen2", "./Stage/costumes/screen2.svg", {
        x: 274.23722648620605,
        y: 183.00000000000006,
      }),
      new Costume("screen3", "./Stage/costumes/screen3.svg", {
        x: 274.23722648620605,
        y: 183.00000000000006,
      }),
      new Costume("Thumbnail", "./Stage/costumes/Thumbnail.svg", {
        x: 349.3123000750751,
        y: 188.44950243112527,
      }),
      new Costume("Title", "./Stage/costumes/Title.svg", {
        x: 274.237215,
        y: 183,
      }),
      new Costume("Settings", "./Stage/costumes/Settings.svg", {
        x: 274.23721500000005,
        y: 183,
      }),
      new Costume("Shop", "./Stage/costumes/Shop.svg", {
        x: 274.23721500000005,
        y: 183,
      }),
    ];

    this.sounds = [
      new Sound("ScratchPack Theme", "./Stage/sounds/ScratchPack Theme.wav"),
      new Sound("Title Screen Music", "./Stage/sounds/Title Screen Music.mp3"),
      new Sound("Shop Music", "./Stage/sounds/Shop Music.mp3"),
      new Sound("Settings Music", "./Stage/sounds/Settings Music.mp3"),
      new Sound("Death Music", "./Stage/sounds/Death Music.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.TIMER_GREATER_THAN,
        { VALUE: () => this.vars.thumbTimer },
        this.whengreaterthan
      ),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.BROADCAST, { name: "Menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.BROADCAST, { name: "Shop" }, this.whenIReceiveShop),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Settings" },
        this.whenIReceiveSettings2
      ),
      new Trigger(Trigger.BROADCAST, { name: "Play" }, this.whenIReceivePlay2),
      new Trigger(Trigger.BROADCAST, { name: "Death" }, this.whenIReceiveDeath),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Death" },
        this.whenIReceiveDeath2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
    ];

    this.vars.thumbTimer = 11.22;
    this.vars.score = 0;
    this.vars.lives = -1;
    this.vars.ammo = 10;
    this.vars.playerVelocity = 0;
    this.vars.money = 0;
    this.vars.HighScore = 346;
    this.vars.difficulty = 1;
    this.vars.mapchange = 1;
    this.vars.soundeffects = 1;
    this.vars.music = 1;
    this.vars.screen = "Menu";
    this.vars.HighScoreUsername = "181916112429192333192222";
    this.vars.charindex = 12;
    this.vars.otherindex = 12;
    this.vars.highScoreHolder = "hifansimwill";
    this.vars.upgrades = [3, 1, 10];
    this.vars.upgradeShow = [
      "Health",
      "Bullet Firing Speed (seconds)",
      "Amount of Ammo",
    ];
    this.vars.upgradeCost = [100, 100, 100];
    this.vars.enemyprojectile = [
      -100,
      52,
      70,
      52,
      -100,
      53,
      70,
      53,
      -100,
      -21,
      70,
      -21,
      70,
      26,
      70,
      -39,
      -100,
      -125,
      70,
      -125,
      70,
      121,
      70,
      -8,
      -100,
      -122,
      70,
      -122,
      -100,
      -39,
      70,
      -39,
      -100,
      18,
      70,
      18,
      70,
      16,
      -100,
      -126,
      70,
      -126,
      -100,
      32,
      70,
      -27,
      80,
      72,
      70,
      -133,
      70,
      -128,
      70,
      -126,
      70,
      32,
      -240,
      105,
      -70,
      105,
      100,
      105,
      -100,
      -108,
      70,
      -108,
      -96,
      -8,
      74,
      -8,
      -86,
      -44,
      74,
      -44,
      -96,
      17,
      74,
      17,
      -96,
      8,
      74,
      8,
      -96,
      -77,
      74,
      -77,
      -246,
      -79,
      -76,
      -79,
      94,
      -79,
      -246,
      74,
      -76,
      74,
      94,
      74,
      -246,
      43,
      -76,
      43,
      94,
      43,
      -236,
      53,
      -66,
      53,
      104,
      53,
      -216,
      -37,
      -46,
      -37,
      94,
      -37,
      -246,
      125,
      -76,
      125,
      94,
      125,
      -246,
      87,
      -76,
      87,
      94,
      87,
      -246,
      124,
      -76,
      124,
      94,
      124,
      -216,
      106,
      -76,
      106,
      94,
      106,
      -242,
      114,
      6,
      114,
      -56,
      -71,
      6,
      21,
      -56,
      -56,
      -56,
      -109,
      254,
      105,
      154,
      -19,
      214,
      23,
      164,
      -19,
      224,
      23,
      174,
      -19,
      234,
      23,
      184,
      -19,
      244,
      23,
      194,
      -19,
      204,
      -19,
      214,
      -19,
      224,
      -19,
      234,
      -19,
      244,
      -19,
      "thing",
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
    ];
    this.vars.characters = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      "a",
      "b",
      "c",
      "d",
      "e",
      "f",
      "g",
      "h",
      "i",
      "j",
      "k",
      "l",
      "m",
      "n",
      "o",
      "p",
      "q",
      "r",
      "s",
      "t",
      "u",
      "v",
      "w",
      "x",
      "y",
      "z",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z",
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      0,
      "-",
      "_",
    ];
    this.vars.highscoreusernamelist = [
      18, 19, 16, 11, 24, 29, 19, 23, 33, 19, 22, 22,
    ];

    this.watchers.HighScore = new Watcher({
      label: "☁ High Score",
      style: "normal",
      visible: false,
      value: () => this.vars.HighScore,
      x: 240,
      y: -133,
    });
    this.watchers.highScoreHolder = new Watcher({
      label: "High Score Holder",
      style: "normal",
      visible: false,
      value: () => this.vars.highScoreHolder,
      x: 240,
      y: 135,
    });
  }

  *whenGreenFlagClicked() {
    this.broadcast("Menu");
    while (true) {
      this.vars.thumbTimer = this.timer;
      yield;
    }
  }

  *whengreaterthan() {
    this.costume = "Thumbnail";
  }

  *whenIReceivePlay() {
    this.vars.mapchange = 0;
    this.costume = "screen1";
    for (let i = 0; i < 2; i++) {
      while (!(this.toNumber(this.vars.mapchange) === 100)) {
        if (this.compare(this.vars.lives, 0) > 0) {
          yield* this.wait(1);
          this.vars.mapchange++;
        } else {
          return;
        }
        yield;
      }
      for (let i = 0; i < 20; i++) {
        this.effects.pixelate += 5;
        yield;
      }
      this.costumeNumber++;
      for (let i = 0; i < 20; i++) {
        this.effects.pixelate -= 5;
        yield;
      }
      this.vars.mapchange = 0;
      yield;
    }
  }

  *whenIReceiveSettings() {
    this.costume = "Settings";
  }

  *whenIReceiveMenu() {
    this.watchers.HighScore.visible = false;
    this.watchers.highScoreHolder.visible = false;
    this.vars.screen = "Menu";
    this.stopAllSounds();
    this.costume = "Title";
    if (this.toNumber(this.vars.music) === 1) {
      while (!!(this.toString(this.vars.screen) === "Menu")) {
        yield* this.playSoundUntilDone("Title Screen Music");
        yield;
      }
    } else {
      this.stopAllSounds();
    }
  }

  *whenIReceiveShop() {
    this.vars.screen = "Shop";
    if (this.toNumber(this.vars.music) === 1) {
      this.vars.music = 0;
      this.stopAllSounds();
      this.costume = "Shop";
      this.vars.music = 1;
      while (!!(this.toString(this.vars.screen) === "Shop")) {
        yield* this.playSoundUntilDone("Shop Music");
        yield;
      }
    }
  }

  *whenIReceiveSettings2() {
    this.watchers.highScoreHolder.visible = true;
    this.watchers.HighScore.visible = true;
    this.vars.screen = "Settings";
    this.costume = "Settings";
    this.stopAllSounds();
    if (this.toNumber(this.vars.music) === 1) {
      while (!!(this.toString(this.vars.screen) === "Settings")) {
        yield* this.playSoundUntilDone("Settings Music");
        yield;
      }
    } else {
      this.stopAllSounds();
    }
  }

  *whenIReceivePlay2() {
    this.vars.screen = "Play";
    this.stopAllSounds();
    if (this.toNumber(this.vars.music) === 1) {
      while (!(this.toNumber(this.vars.lives) === 0)) {
        yield* this.playSoundUntilDone("ScratchPack Theme");
        yield;
      }
      this.stopAllSounds();
    }
  }

  *whenIReceiveDeath() {
    this.vars.screen = "Death";
    this.stopAllSounds();
    if (this.toNumber(this.vars.music) === 1) {
      while (!!(this.toNumber(this.vars.lives) === 0)) {
        yield* this.playSoundUntilDone("Death Music");
        yield;
      }
      this.stopAllSounds();
    }
  }

  *whenGreenFlagClicked2() {
    this.vars.characters = [];
    for (let i = 0; i < 10; i++) {
      this.vars.characters.push("");
      yield;
    }
    this.vars.characters.push("a");
    this.vars.characters.push("b");
    this.vars.characters.push("c");
    this.vars.characters.push("d");
    this.vars.characters.push("e");
    this.vars.characters.push("f");
    this.vars.characters.push("g");
    this.vars.characters.push("h");
    this.vars.characters.push("i");
    this.vars.characters.push("j");
    this.vars.characters.push("k");
    this.vars.characters.push("l");
    this.vars.characters.push("m");
    this.vars.characters.push("n");
    this.vars.characters.push("o");
    this.vars.characters.push("p");
    this.vars.characters.push("q");
    this.vars.characters.push("r");
    this.vars.characters.push("s");
    this.vars.characters.push("t");
    this.vars.characters.push("u");
    this.vars.characters.push("v");
    this.vars.characters.push("w");
    this.vars.characters.push("x");
    this.vars.characters.push("y");
    this.vars.characters.push("z");
    this.vars.characters.push("A");
    this.vars.characters.push("B");
    this.vars.characters.push("C");
    this.vars.characters.push("D");
    this.vars.characters.push("E");
    this.vars.characters.push("F");
    this.vars.characters.push("G");
    this.vars.characters.push("H");
    this.vars.characters.push("I");
    this.vars.characters.push("J");
    this.vars.characters.push("K");
    this.vars.characters.push("L");
    this.vars.characters.push("M");
    this.vars.characters.push("N");
    this.vars.characters.push("O");
    this.vars.characters.push("P");
    this.vars.characters.push("Q");
    this.vars.characters.push("R");
    this.vars.characters.push("S");
    this.vars.characters.push("T");
    this.vars.characters.push("U");
    this.vars.characters.push("V");
    this.vars.characters.push("W");
    this.vars.characters.push("X");
    this.vars.characters.push("Y");
    this.vars.characters.push("Z");
    this.vars.characters.push(1);
    this.vars.characters.push(2);
    this.vars.characters.push(3);
    this.vars.characters.push(4);
    this.vars.characters.push(5);
    this.vars.characters.push(6);
    this.vars.characters.push(7);
    this.vars.characters.push(8);
    this.vars.characters.push(9);
    this.vars.characters.push(0);
    this.vars.characters.push("-");
    this.vars.characters.push("_");
  }

  *whenIReceiveDeath2() {
    if (this.compare(this.vars.score, this.vars.HighScore) > 0) {
      this.vars.charindex = 0;
      this.vars.HighScoreUsername = "";
      this.vars.highScoreHolder = "";
      this.vars.HighScore = this.vars.score;
      while (
        !(this.compare(this.vars.charindex, /* no username */ "".length) === 0)
      ) {
        this.vars.charindex++;
        this.vars.HighScoreUsername =
          this.toString(this.vars.HighScoreUsername) +
          this.toString(
            this.indexInArray(
              this.vars.characters,
              this.letterOf(/* no username */ "", this.vars.charindex - 1)
            ) + 1
          );
        yield;
      }
      yield* this.dostuff();
    }
  }

  *whenGreenFlagClicked3() {
    yield* this.dostuff();
  }

  *dostuff() {
    this.vars.highScoreHolder = "";
    this.vars.otherindex = 0;
    this.vars.highscoreusernamelist = [];
    for (let i = 0; i < /* no username */ "".length; i++) {
      this.vars.otherindex++;
      this.vars.highscoreusernamelist.push(
        this.letterOf(this.vars.HighScoreUsername, this.vars.otherindex - 1) +
          this.letterOf(
            this.vars.HighScoreUsername,
            this.toNumber(this.vars.otherindex)
          )
      );
      this.vars.otherindex++;
      yield;
    }
    this.vars.otherindex = 0;
    for (let i = 0; i < /* no username */ "".length; i++) {
      this.vars.otherindex++;
      this.vars.highScoreHolder =
        this.toString(this.vars.highScoreHolder) +
        this.toString(
          this.itemOf(
            this.vars.characters,
            this.itemOf(
              this.vars.highscoreusernamelist,
              this.vars.otherindex - 1
            ) - 1
          )
        );
      yield;
    }
  }
}
